package pl.swierzowski.jwt_tokeny.controller;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.web.bind.annotation.*;
import pl.swierzowski.jwt_tokeny.entity.User;

import java.util.Date;

@RestController
public class TestApi {

    // for all
    @GetMapping("/test1")
    public String test1(){
        return "test1";
    }
    // zalogowani
    @GetMapping("/test2")
    public String test2(){
        return "test2";
    }
// rola
    @GetMapping("/test3")
    public String test3(){
        return "test3";
    }



}
