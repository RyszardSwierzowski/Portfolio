package pl.swierzowski.jwt_tokeny.controller;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.swierzowski.jwt_tokeny.entity.User;
import pl.swierzowski.jwt_tokeny.repository.UserRepository;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
public class LoginApi {

    @Autowired
    UserRepository userRepository;

    @GetMapping("/xxx")
    public ResponseEntity<String> logIn(@RequestBody User user) {
        Optional<User> userFromDatabase = userRepository.findByLoginAndPassword(user.getLogin(), user.getPassword());
        if (!userFromDatabase.isPresent())
            return new ResponseEntity<>("brak autoryzacji", HttpStatus.UNAUTHORIZED);
        //throw new EntityNotFoundException("User not found");


        long currentTimeMillis = System.currentTimeMillis();

        String responseToken = Jwts.builder()
                .setSubject(user.getLogin()) // ustawiam kto jest userem i kto dostaje ten klucz
                .setHeaderParam("typ", "JWT")
                .claim("role", "ROLE_USER")
                .claim("name", "imie nazwisko")
                .claim("userID", userFromDatabase.get().getId())
                .setIssuedAt(new Date(currentTimeMillis))   // czas ważności tokenu
                .setExpiration(new Date(currentTimeMillis + (1000 * 2000))) // czas przez jaki token jest żywy
                .signWith(SignatureAlgorithm.HS512, "aaa".getBytes())
                .compact();  // compact zwraca bulidera jako stringa


        return ResponseEntity.ok()
                .body(responseToken);
    }

    @GetMapping("/x")
    public String get(@RequestBody User user) {

        long currentTimeMillis = System.currentTimeMillis();

        return Jwts.builder()
                .setSubject(user.getLogin()) // ustawiam kto jest userem i kto dostaje ten klucz
                .setHeaderParam("typ", "JWT")
                .claim("role", "ROLE_USER")
                .claim("name", "imie nazwisko")
                .setIssuedAt(new Date(currentTimeMillis))   // czas ważności tokenu
                .setExpiration(new Date(currentTimeMillis + (1000 * 2000))) // czas przez jaki token jest żywy
                .signWith(SignatureAlgorithm.HS512, "aaa".getBytes())
                .compact();  // compact zwraca bulidera jako stringa


    }
}
