package pl.swierzowski.jwt_tokeny;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import pl.swierzowski.jwt_tokeny.entity.User;
import pl.swierzowski.jwt_tokeny.repository.UserRepository;

@SpringBootApplication
public class JwtTokenyApplication implements CommandLineRunner {

    @Autowired
    UserRepository userRepository;
    public static void main(String[] args) {
        SpringApplication.run(JwtTokenyApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        User user = new User();
        user.setLogin("X");
        user.setPassword("X");
        userRepository.save(user);
    }

//    @Bean
//    public FilterRegistrationBean filterRegistrationBean(){
//        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
//        filterRegistrationBean.setFilter(new JwtFilterLogowanie());
//        filterRegistrationBean.setUrlPatterns(Collections.singleton("/logIn"));
//        return filterRegistrationBean;
//    }
}
